<?php
    session_start();
    if(!isset($_COOKIE['rem'])) {
        header('location: logout.php');
    }
    if(!isset($_SESSION['id'])) {
        header('location: login.php');
    }
?>


<!-- PHP Start -->
<?php

// Variable
$firstnameErrMsg = "";
$lastnameErrMsg= "";
$GendernameErrMsg= ""; 
$emailErrMsg= "";
$phoneErrMsg= "";
$roadErrMsg="";
$userErrMsg="";
$passwordErrMsg="";
$confirm_passwordErrMsg="";


$isvalid=true;

// First Name Start
if ($_SERVER['REQUEST_METHOD'] === "POST"){
	$flag=false;
	if(empty($_POST['FirstName'])) {
		//echo "First Name Empty";
		$firstnameErrMsg = "First Name Empty";
		$flag=true;
		//echo "<br>";
	}
	else {
			if (!preg_match("/^[a-zA-Z-' ]*$/",$_POST['FirstName'])) {
			echo "Only letters and spaces allowed.";
			$firstnameErrMsg = "Only letters and spaces allowed";
			echo "<br>";
			}
		}	
// First Name End

// Last Name Start		
		if(empty($_POST['LastName'])) {
			//echo "Last Name Empty";
			$lastnameErrMsg = "Last Name Empty";
			$flag=true;
			//echo "<br>";
		}
		else {
				if (!preg_match("/^[a-zA-Z-' ]*$/",$_POST['LastName'])) {
				echo "Only letters and spaces allowed.";
				$lastnameErrMsg = "Only letters and spaces allowed";
				echo "<br>";
				}
			}	
// Last Name End		

// Gender
		if(empty($_POST['Gender'])) {
			//echo "Gender not Selected";
			$GendernameErrMsg = "Gender not Selected";
			$flag=true;
			//echo "<br>";
		}

// Email Start 
		if(empty($_POST['email'])) {
			//echo "Email is Empty";
			$emailErrMsg = "Email is Empty";
			$flag=true;
			//echo "<br>";
		}
		else {
				if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
				echo "Please correct email";
				$emailErrMsg = "Please correct email";
				echo "<br>";
				}
			}	
// Email End

// Number Start
			if(empty($_POST['number'])) {
			//echo "MobileNo is Empty";
			$phoneErrMsg= "Mobileno is Empty";
			$flag=true;
			//echo "<br>";
		}
// Road Start		
		if(empty($_POST['road'])) {
			//echo "Street/House/Road/ is Empty";
			$roadErrMsg= "Street/House/Road/ is Empty";
			$flag=true;
			//echo "<br>";
		}
	

// Json File Start 		
	if(!$flag)
	{
        define("file","data.json"); // file extension
        $handle = fopen(file, "r"); // file open
        $json = NULL; 

        if(filesize(file) > 0) // file size
        {
            $fr = fread($handle, filesize(file)); // file read
            $json = json_decode($fr); // $fr file decode 
            fclose($handle);// $ handel close 
        }

        $handle = fopen(file, "w");// file write
        if($json != NULL) {
            $id = $json[count($json)-1]->id;
            $json[] = @array("id" => $id + 1,
                        "First_name" => $_POST['FirstName'],
                        "Last_name" => $_POST['LastName'],
                        "Gender" => $_POST['Gender'],
                        "Email" => $_POST['email'],
                        "Phone_Number" =>$_POST['number'],
                        "Road" => $_POST['road'],
                        "Country" => $_POST['country'],
                    );
                    $data = json_encode($json); // json_encode unlock
        }
        fwrite($handle, $data); // file write 
        
        $_SESSION['fname'] = $_POST['FirstName'];
        $_SESSION['lname'] = $_POST['LastName'];
        $_SESSION['gender'] = $_POST['Gender'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['phone'] = $_POST['number'];   
        $_SESSION['road'] = $_POST['country'];   
        $_SESSION['country'] = $json[$i]->Country;
        header("location: Profile.php");
        fclose($handle);// file close
    }
}
?>
<!-- PHP End -->




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
</head>
<body>
    <?php include('../View/Profile-header.php'); ?>
    <form action="update.php" method="POST">
    <fieldset style="width: 40%;">
        <legend><h3>Update Profile</h1></legend>
            <table>
                <tbody>
                    <tr>
                        <td>
                            <label for="fname">First Name</label> 
                        </td>
                        <td>
                            <input name="FirstName" value="<?php echo $_SESSION['fname']; ?>" id="fname">
                            <span><?php echo $firstnameErrMsg; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="lname">Last Name</label> 
                        </td>
                        <td>
                            <input name="LastName"  value="<?php echo $_SESSION['lname']; ?>" id="lname">
                            <span><?php echo $lastnameErrMsg; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="gender">Gender</label> 
                        </td>
                        <td>
                            <input type="radio" name="Gender" value="male">Male
                            <input type="radio" name="Gender" value="Female">Female
                            <input type="radio" name="Gender" value="Other">Other
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="email">Email</label> 
                        </td>
                        <td>
                            <input name="Email"  value="<?php echo $_SESSION['email']; ?>" id="email">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="phone">Phone</label> 
                        </td>
                        <td>
                            <input name="Phone"  value="<?php echo $_SESSION['phone']; ?>" id="phone">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="road">Road</label> 
                        </td>
                        <td>
                            <input name="Address"  value="<?php echo $_SESSION['road']; ?>" id="road">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="country">Country</label> 
                        </td>
                        <td>
                            <input name="Address"  value="<?php echo $_SESSION['country']; ?>" id="country">
                        </td>
                    </tr>
                </tbody>
            </table>
        <br>
        <!-- Register -->
	<input type="submit" name="submit"value="Update">
</form>
    </fieldset>

    <br>
    <?php include('../View/footer.html'); ?>
</body>
</html>