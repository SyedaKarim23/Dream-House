<!DOCTYPE HTML>  
<html>
<head>
<title>Reset password</title>

	<style type="text/css">
		.red{
			color: red;
		}
	</style>
</head>
<body>  

<!-- Header  -->
<?php include('../View/header.html'); ?>

<?php
// define variables and set to empty values
$usernameErr = $passwordErr = $confirmpasswordErr = "";
$username =  $password = $confirmpassword = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{ 
#Password Verification
if (empty($_POST["password"])) {
    $passwordErr = "Password is required";
}
else{
    $password = $_POST["password"];

    if (strlen($password) < 8) {
        $passwordErr = "Password must be contain at least 8 characters";
    }
    else if (!preg_match("@[^\w]@",$password))
    {
        $passwordErr = "use one special character";
    }

    // Confirm Password	
    if (empty($_POST["cofirmpassword"])) {
        $confirmpasswordErr = "Password is required";
    }

	else if(($_POST["password"])!=($_POST["cofirmpassword"])) {
		//echo "Confirm Password Empty";
		$confirmpasswordErr="Confirm Password Error";
	
		}
        
	
	
}
      
}

  ?>

<div class="container" style="width: 600px;">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
<fieldset>
  <legend> <h2>Reset Password</h2></legend> 
  <label>Password:</label>
				<input type="password" name="password" value="<?php echo $password;?>"><span class="red">*<?php echo $passwordErr ?></span> <br><br>
                <label>Confirm Password:</label>
				<input type="password" name="cofirmpassword" value="<?php echo $confirmpassword;?>"><span class="red">*<?php echo $confirmpasswordErr ?></span> <br><br>             
  <input type="submit" name="submit" value="Submit"> 
  </fieldset>
</form>
</div>
<br><br>
<!-- footer -->
<?php include('../View/footer.html'); ?>








