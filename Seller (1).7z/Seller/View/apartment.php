<?php
    session_start();
	if(!isset($_COOKIE['rem'])) {
        header('location: logout.php');
    }
    if(!isset($_SESSION['id'])) {
        header('location: login.php');
    }
?>

<?php          
		include ('profile-header.php'); 
	?>
<!DOCTYPE html>
<html>
<head>
</head>
<body> 
<!-- PHP Start -->
<?php
// Variable
$BDTErrMsg="";
$RoadErrMsg="";
$ApartmentErrMsg=" ";
$EmailErrMsg=" ";
$phoneErrMsg=""; 



if ($_SERVER['REQUEST_METHOD'] === "POST"){
	$flag=false;
	if(empty($_POST['BDT'])) {
		$BDTErrMsg = "BDT Name Empty";
		$flag=true;
	}	
		if(empty($_POST['Road'])) {
			$RoadErrMsg = "Road Name Empty";
			$flag=true;
		}
		if(empty($_POST['Apartment'])) {
			$ApartmentErrMsg = "Apartment not Selected";
			$flag=true;
		}
		if(empty($_POST['Email'])) {
			$EmailErrMsg = "Email is Empty";
			$flag=true;
		}
		else {
				if (!filter_var($_POST['Email'], FILTER_VALIDATE_EMAIL)) {
				$EmailErrMsg = "Please correct email";
				echo "<br>";
				}
			}	
			if(empty($_POST['phone'])) {
			$phoneErrMsg= "Mobile no is Empty";
			$flag=true;
		}

		if (!$flag) {
			echo " Successful";
		}
	



// Json File Start 		
	if(!$flag )
	{
		define("file","apartment.json"); // file extension
		$handle = fopen(file, "r"); // file open
		$json = NULL; 

	if(filesize(file) > 0) // file size
    {
		$fr = fread($handle, filesize(file)); // file read
		$json = json_decode($fr); // $fr file decode 
		fclose($handle);// $ handel close 
	}

	$handle = fopen(file, "w");// file write
	if($json == NULL){
		$id = 1;
		$data = @array(array("id" => $id,
							"BDT" => $_POST['BDT'],
                            "Road" => $_POST['Road'],
                            "Apartment" => $_POST['Apartment'],
                            "Email" => $_POST['Email'],
                            "phone" =>$_POST['phone'],
						));
		$data = json_encode($data); // json_encode unlock
	}
	
	else {
        $id = $json[count($json)-1]->id;
                            $json[] = @array("id" => $id + 1,
                            "BDT" => $_POST['BDT'],
                            "Road" => $_POST['Road'],
                            "Apartment" => $_POST['Apartment'],
                            "Email" => $_POST['Email'],
                            "phone" =>$_POST['phone'],
                        );
                    $data = json_encode($json); // json_encode unlock
    }
    fwrite($handle, $data); // file write 
    fclose($handle);// file close
}
	}
?>
<!-- PHP End -->


<!-- HTML Start -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" novalidate>
	<!-- General Start -->
	
	<fieldset>
		<legend><h3>Apartment Add</h3></legend>
<table>
	<thead></thead>
	<tbody>
        <tr>
			<td>BDT</td>
			<td><label for="BDT"></label>
				<input type="text" name="BDT"placeholder="BDT"autofocus>
				<span><?php echo $BDTErrMsg; ?></span>
			</td>
		</tr>
        <tr>	
			<td>Road No</td>
			<td><label for="Road"></label>
				<input type="text" name="Road"placeholder="Road"autofocus>
				<span><?php echo $RoadErrMsg; ?></span>
			</td>
		</tr>	
        <tr>	
			<td>Apartment</td>
			<td><label for="Apartment"></label>
				<input type="text" name="Apartment"placeholder="Apartment"autofocus>
				<span><?php echo $ApartmentErrMsg; ?></span>
			</td>
		</tr>	
        <tr>
			<td>Email</td>
			<td><input type="Email" name="Email">
			<span><?php echo $EmailErrMsg; ?></span></td>
		</tr>	
        <tr>
			<td>Mobile No</td>
			<td><input type="phone" name="phone">
			<span><?php echo $phoneErrMsg; ?></span></td>
		</tr>	
			</tbody>
			</table>
			<br>
			<input type="submit" name="Register"value="Register">
</fieldset>
<br><br>
</form>
<!-- HTML End -->
<?php include('../View/footer.html'); ?>
