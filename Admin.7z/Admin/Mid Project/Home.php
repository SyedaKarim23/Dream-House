<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>

	<div class="container">
		<form method="post" action="<?php echo ($_SERVER['PHP_SELF']);?>" novalidate>

			<div>
				<?php include '../Mid Project/View//Header.php';?>				
			</div>
			<p style="font-size: 30px;" align='center'><b>Welcome to  Dream House!!! </b></p>
			<!-- <div style="height: 100px;" align="center">
				<p style="font-size: 30px;"><b>Welcome to  Dream House!!! </b></p>
			</div>  -->

			<p align="center">
				<img src="House_logo.png" width="250px" >
			</p>

			<div align="center">
				<?php include '../Mid Project/View/Footer.php';?>
			</div>			
			
		</form>
	</div>

</body>
</html>