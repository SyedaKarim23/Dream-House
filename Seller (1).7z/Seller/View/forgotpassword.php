<!DOCTYPE HTML>  
<html>
<head>
<title>Forgotpassword</title>

	<style type="text/css">
		.red{
			color: red;
		}
	</style>
</head>
<body>  

<!-- Header  -->
<?php include('../View/header.html'); ?>

<?php
// define variables and set to empty values
$usernameErr = $emailErrMsg= "";
$username = $email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{ 
	$flag=false;
#Name Validation
  if (empty($_POST["email"])) 
  {
    $emailErrMsg = "Email is required";
	$flag=true;
  } 
  if (!$flag) {
	
	
}
      
}

  ?>

<div class="container" style="width: 500px;">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
<fieldset>
  <legend> <h2>forgot Password</h2></legend> 
                <label>Email:</label>
				<input type="email" name="email" value="<?php echo $email ;?>"><span class="red">*<?php echo $emailErrMsg ?></span> <br><br>
				<hr>
  <input type="submit" name="submit" value="Submit"> 
  </fieldset>
</form>
</div>
<?php
if (!empty($_POST["email"])) 
header('Location: login.php');
?>

<!-- footer -->
<?php include('../View/footer.html'); ?>








